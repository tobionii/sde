package com.movieranker.api.controller;

import java.util.UUID;
import java.util.List;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.movieranker.api.dto.TMDB.ReplaceTopMoviesRequest;
import com.movieranker.api.dto.TMDB.TopMovieResponse;
import com.movieranker.api.dto.profile.CreateProfileRequest;
import com.movieranker.api.dto.profile.ProfileResponse;
import com.movieranker.api.dto.profile.UpdateProfileRequest;
import com.movieranker.api.service.ProfileService;
import com.movieranker.api.service.TopMovieService;

@RestController
@RequestMapping("/api/me")
@RequiredArgsConstructor
public class MeController {
    private final ProfileService profileService;

    @GetMapping
    public ProfileResponse me(@AuthenticationPrincipal Jwt jwt) {
        return ProfileResponse.from(profileService.getOrThrow(userId(jwt)));
    }

    @PostMapping("/profile")
    @ResponseStatus(HttpStatus.CREATED)
    public ProfileResponse create(@AuthenticationPrincipal Jwt jwt,
                                  @Valid @RequestBody CreateProfileRequest req) {
        return ProfileResponse.from(profileService.create(userId(jwt), req));
    }

    @PatchMapping
    public ProfileResponse update(@AuthenticationPrincipal Jwt jwt,
                                  @Valid @RequestBody UpdateProfileRequest req) {
        return ProfileResponse.from(profileService.update(userId(jwt), req));
    }

    private final TopMovieService topMovieService;
    @GetMapping("/top-movies")
    public List<TopMovieResponse> topMovies(@AuthenticationPrincipal Jwt jwt) {
    return topMovieService.get(userId(jwt));
    }

    @PutMapping("/top-movies")
    public List<TopMovieResponse> replaceTopMovies(@AuthenticationPrincipal Jwt jwt,
                                               @Valid @RequestBody ReplaceTopMoviesRequest req) {
    return topMovieService.replace(userId(jwt), req.movies());
    }

    private static UUID userId(Jwt jwt) {
        return UUID.fromString(jwt.getSubject());
    }
}