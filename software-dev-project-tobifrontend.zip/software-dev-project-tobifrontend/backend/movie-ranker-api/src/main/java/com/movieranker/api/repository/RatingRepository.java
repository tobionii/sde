package com.movieranker.api.repository;

import com.movieranker.api.entity.Rating;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface RatingRepository extends JpaRepository<Rating, Long> {
    Optional<Rating> findByUserIdAndMovieListId(UUID userId, Long movieListId);
    List<Rating> findByMovieListId(Long movieListId);

    interface Summary {
        Double getAverage();
        Long getTotal();
    }

    @Query("select avg(r.score) as average, count(r) as total " +
           "from Rating r where r.movieListId = :listId")
    Summary summarize(@Param("listId") Long listId);
}

