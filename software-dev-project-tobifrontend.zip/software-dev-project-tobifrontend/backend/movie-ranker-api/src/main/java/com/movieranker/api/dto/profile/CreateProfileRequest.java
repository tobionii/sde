
package com.movieranker.api.dto.profile;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

public record CreateProfileRequest(
    @NotBlank @Size(min = 3, max = 30)
    @Pattern(regexp = "^[a-zA-Z0-9_]+$", message = "letters, numbers, underscores only")
    String username,
    @Size(max = 100) String displayName,
    @Size(max = 500) String bio
) {}
