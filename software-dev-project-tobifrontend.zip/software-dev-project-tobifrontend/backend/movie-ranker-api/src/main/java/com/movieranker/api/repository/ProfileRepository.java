package com.movieranker.api.repository;

import java.util.Optional;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;

import com.movieranker.api.entity.Profile;

public interface ProfileRepository extends JpaRepository<Profile, UUID> {
    boolean existsByUsername(String username);
    Optional<Profile> findByUsername(String username);
}