package com.movieranker.api.dto.profile;

import java.util.UUID;

import com.movieranker.api.entity.Profile;

public record ProfileResponse(UUID id, String username, String displayName, String bio) {
    public static ProfileResponse from(Profile p) {
        return new ProfileResponse(p.getId(), p.getUsername(), p.getDisplayName(), p.getBio());
    }
}