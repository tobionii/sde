package com.movieranker.api.controller;

import com.movieranker.api.dto.profile.ProfileResponse;
import com.movieranker.api.dto.TMDB.PublicProfileResponse;
import com.movieranker.api.entity.Profile;
import com.movieranker.api.service.ProfileService;
import com.movieranker.api.service.TopMovieService;
import com.movieranker.api.service.RatingService;

import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;


@RestController
@RequestMapping("/api/users")
@RequiredArgsConstructor
public class UserController {
    private final ProfileService profileService;
    private final TopMovieService topMovieService;
    private final RatingService ratingService;

    @GetMapping("/{username}")
    public PublicProfileResponse get(@PathVariable String username) {
        Profile p = profileService.getByUsernameOrThrow(username);
        Long listId = topMovieService.getListId(p.getId());
        return new PublicProfileResponse(
            ProfileResponse.from(p),
            listId,
            topMovieService.get(p.getId()),
            ratingService.summary(listId));
    }
}

