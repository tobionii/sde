package com.movieranker.api.dto.TMDB;

public record RatingResponse(String username, int score) {}
