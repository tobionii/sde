package com.movieranker.api.dto.TMDB;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.NotNull;

public record TopMovieItem(
    @NotNull Integer tmdbId,
    @NotNull @Min(1) @Max(5) Integer position
) {}