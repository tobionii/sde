package com.movieranker.api.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.util.List;

import com.movieranker.api.entity.ListMovie;
public interface ListMovieRepository extends JpaRepository<ListMovie, Long> {
    List<ListMovie> findByListIdOrderByPositionAsc(Long listId);

  
    @Modifying(flushAutomatically = true)
    @Query("delete from ListMovie lm where lm.listId = :listId")
    void deleteAllForList(@Param("listId") Long listId);
}
