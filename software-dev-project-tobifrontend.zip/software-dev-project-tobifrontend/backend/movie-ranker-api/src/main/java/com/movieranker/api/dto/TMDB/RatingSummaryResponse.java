package com.movieranker.api.dto.TMDB;

public record RatingSummaryResponse(double average, long count) {}
