package com.movieranker.api.dto.TMDB;


public record TopMovieResponse(int position, MovieDto movie) {}
