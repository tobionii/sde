package com.movieranker.api.dto.TMDB;

import com.movieranker.api.dto.profile.ProfileResponse;
import java.util.List;
public record PublicProfileResponse(
    ProfileResponse profile,
    Long listId,                       // null if they haven't saved a top 5 yet
    List<TopMovieResponse> topMovies,
    RatingSummaryResponse rating) {}

