    package com.movieranker.api.service;

    import com.movieranker.api.dto.TMDB.MovieDto;
    import com.movieranker.api.dto.TMDB.TopMovieItem;
    import com.movieranker.api.dto.TMDB.TopMovieResponse;
    import com.movieranker.api.entity.ListMovie;
    import com.movieranker.api.entity.Movie;
    import com.movieranker.api.entity.MovieList;
    import com.movieranker.api.repository.ListMovieRepository;
    import com.movieranker.api.repository.MovieListRepository;
    import com.movieranker.api.repository.MovieRepository;
    import lombok.RequiredArgsConstructor;
    import org.springframework.http.HttpStatus;
    import org.springframework.stereotype.Service;
    import org.springframework.transaction.annotation.Transactional;
    import org.springframework.web.server.ResponseStatusException;

    import java.util.List;
    import java.util.Map;
    import java.util.UUID;
    import java.util.stream.Collectors;


    @Service
    @RequiredArgsConstructor
    public class TopMovieService {
        private final MovieListRepository movieLists;
        private final ListMovieRepository listMovies;
        private final MovieRepository movies;
        private final MovieService movieService;
        private final ProfileService profileService;

        /** The id of this user's list, or null if they haven't saved one yet. */
        public Long getListId(UUID userId) {
            return movieLists.findByUserId(userId).map(MovieList::getId).orElse(null);
        }

        public List<TopMovieResponse> get(UUID userId) {
            return movieLists.findByUserId(userId).map(this::toResponses).orElse(List.of());
        }

        @Transactional
        public List<TopMovieResponse> replace(UUID userId, List<TopMovieItem> items) {
            profileService.getOrThrow(userId);   // must have a profile first

            long distinctPositions = items.stream().map(TopMovieItem::position).distinct().count();
            long distinctMovies = items.stream().map(TopMovieItem::tmdbId).distinct().count();
            if (distinctPositions != items.size() || distinctMovies != items.size())
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                    "Positions and movies must each be unique");

            // Find or create the user's single list
            MovieList list = movieLists.findByUserId(userId).orElseGet(() -> {
                MovieList l = new MovieList();
                l.setUserId(userId);
                return movieLists.save(l);
            });

            // Resolve every movie BEFORE touching the old list, so a bad TMDB id
            // fails the request without wiping anything
            List<Movie> resolved = items.stream()
                .map(i -> movieService.getOrCreate(i.tmdbId()))
                .toList();

            listMovies.deleteAllForList(list.getId());
            for (int i = 0; i < items.size(); i++) {
                ListMovie lm = new ListMovie();
                lm.setListId(list.getId());
                lm.setMovieId(resolved.get(i).getId());
                lm.setPosition(items.get(i).position());
                listMovies.save(lm);
            }
            return toResponses(list);
        }

        private List<TopMovieResponse> toResponses(MovieList list) {
            List<ListMovie> rows = listMovies.findByListIdOrderByPositionAsc(list.getId());
            Map<Long, Movie> byId = movies
                .findAllById(rows.stream().map(ListMovie::getMovieId).toList())
                .stream().collect(Collectors.toMap(Movie::getId, m -> m));
            return rows.stream()
                .map(r -> new TopMovieResponse(r.getPosition(), MovieDto.fromEntity(byId.get(r.getMovieId()))))
                .toList();
        }
    }
