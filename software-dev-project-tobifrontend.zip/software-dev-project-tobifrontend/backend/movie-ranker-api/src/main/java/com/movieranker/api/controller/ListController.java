package com.movieranker.api.controller;

import com.movieranker.api.dto.TMDB.RatingRequest;
import com.movieranker.api.dto.TMDB.RatingResponse;
import com.movieranker.api.dto.TMDB.RatingSummaryResponse;
import com.movieranker.api.service.RatingService;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/lists")
@RequiredArgsConstructor
public class ListController {
    private final RatingService ratingService;

    @PutMapping("/{listId}/rating")
    public RatingSummaryResponse rate(@AuthenticationPrincipal Jwt jwt,
                                      @PathVariable Long listId,
                                      @Valid @RequestBody RatingRequest req) {
        return ratingService.rate(UUID.fromString(jwt.getSubject()), listId, req.score());
    }

    @GetMapping("/{listId}/rating")
    public RatingSummaryResponse summary(@PathVariable Long listId) {
        return ratingService.summary(listId);
    }

    @GetMapping("/{listId}/ratings")
    public List<RatingResponse> ratings(@PathVariable Long listId) {
        return ratingService.listRatings(listId);
    }
}

