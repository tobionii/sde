package com.movieranker.api.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

import com.movieranker.api.entity.Movie;
public interface MovieRepository extends JpaRepository<Movie, Long> {
    Optional<Movie> findByTmdbId(Integer tmdbId);
}

