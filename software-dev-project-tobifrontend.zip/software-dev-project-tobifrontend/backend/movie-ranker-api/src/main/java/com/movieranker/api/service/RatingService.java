package com.movieranker.api.service;

import com.movieranker.api.dto.TMDB.RatingResponse;
import com.movieranker.api.dto.TMDB.RatingSummaryResponse;
import com.movieranker.api.entity.MovieList;
import com.movieranker.api.entity.Profile;
import com.movieranker.api.entity.Rating;
import com.movieranker.api.repository.MovieListRepository;
import com.movieranker.api.repository.ProfileRepository;
import com.movieranker.api.repository.RatingRepository;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class RatingService {
    private final RatingRepository ratings;
    private final MovieListRepository movieLists;
    private final ProfileRepository profiles;
    private final ProfileService profileService;

    @Transactional
    public RatingSummaryResponse rate(UUID userId, Long listId, int score) {
        profileService.getOrThrow(userId);                          // rater needs a profile
        MovieList list = movieLists.findById(listId).orElseThrow(() ->
            new ResponseStatusException(HttpStatus.NOT_FOUND, "List not found"));

        if (list.getUserId().equals(userId))
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "You can't rate your own list");

        Rating r = ratings.findByUserIdAndMovieListId(userId, listId)
            .orElseGet(Rating::new);                                // update if exists, else create
        r.setUserId(userId);
        r.setMovieListId(listId);
        r.setScore(score);
        ratings.save(r);

        return summary(listId);
    }

    public RatingSummaryResponse summary(Long listId) {
        if (listId == null) return new RatingSummaryResponse(0, 0);
        RatingRepository.Summary s = ratings.summarize(listId);
        double avg = s.getAverage() == null ? 0 : Math.round(s.getAverage() * 10) / 10.0;
        return new RatingSummaryResponse(avg, s.getTotal() == null ? 0 : s.getTotal());
    }

    public List<RatingResponse> listRatings(Long listId) {
        List<Rating> rows = ratings.findByMovieListId(listId);
        Map<UUID, String> names = profiles
            .findAllById(rows.stream().map(Rating::getUserId).toList())
            .stream().collect(Collectors.toMap(Profile::getId, Profile::getUsername));
        return rows.stream()
            .map(r -> new RatingResponse(names.get(r.getUserId()), r.getScore()))
            .toList();
    }
}

