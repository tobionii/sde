package com.movieranker.api.service;

import java.util.UUID;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import com.movieranker.api.dto.profile.CreateProfileRequest;
import com.movieranker.api.dto.profile.UpdateProfileRequest;
import com.movieranker.api.entity.Profile;
import com.movieranker.api.repository.ProfileRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class ProfileService {
    private final ProfileRepository profiles;

    public Profile getOrThrow(UUID userId) {
        return profiles.findById(userId).orElseThrow(() ->
            new ResponseStatusException(HttpStatus.NOT_FOUND, "Profile not found. Create one first."));
    }

    public Profile getByUsernameOrThrow(String username) {
        return profiles.findByUsername(username.toLowerCase()).orElseThrow(() ->
            new ResponseStatusException(HttpStatus.NOT_FOUND, "No such user"));
    }

    @Transactional
    public Profile create(UUID userId, CreateProfileRequest req) {
        if (profiles.existsById(userId))
            throw new ResponseStatusException(HttpStatus.CONFLICT, "You already have a profile");
        String username = req.username().toLowerCase();
        if (profiles.existsByUsername(username))
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Username taken");

        Profile p = new Profile();
        p.setId(userId);
        p.setUsername(username);
        p.setDisplayName(req.displayName());
        p.setBio(req.bio());
        return profiles.save(p);
    }

    @Transactional
    public Profile update(UUID userId, UpdateProfileRequest req) {
        Profile p = getOrThrow(userId);
        if (req.displayName() != null) p.setDisplayName(req.displayName());
        if (req.bio() != null) p.setBio(req.bio());
        return p;   // managed entity: saved automatically at end of transaction
    }
}