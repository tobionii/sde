package com.movieranker.api.dto.TMDB;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.Max;

public record RatingRequest(@NotNull @Min(1) @Max(5) Integer score) {}
