    package com.movieranker.api.service;

    import com.movieranker.api.entity.Movie;
    import com.movieranker.api.repository.MovieRepository;
    import com.movieranker.api.dto.TMDB.TmdbMovie;
    import lombok.RequiredArgsConstructor;
    import org.springframework.stereotype.Service;

    import java.time.LocalDate;

    @Service
    @RequiredArgsConstructor
    public class MovieService {
        private final MovieRepository movies;
        private final TmdbService tmdb;

        public Movie getOrCreate(int tmdbId) {
            return movies.findByTmdbId(tmdbId).orElseGet(() -> {
                TmdbMovie t = tmdb.getMovie(tmdbId);   // 404s if the id isn't real
                Movie m = new Movie();
                m.setTmdbId(t.id());
                m.setTitle(t.title());
                m.setOverview(t.overview());
                m.setPosterPath(t.posterPath());
                m.setBackdropPath(t.backdropPath());
                m.setReleaseDate(parseDate(t.releaseDate()));
                return movies.save(m);
            });
        }


        private static LocalDate parseDate(String s) {
            return (s == null || s.isBlank()) ? null : LocalDate.parse(s);
        }
    }


