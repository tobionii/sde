package com.movieranker.api.dto.TMDB;

import com.movieranker.api.entity.Movie;

public record MovieDto(
    int tmdbId,
    String title,
    String overview,
    String posterUrl,
    String backdropUrl,
    String releaseDate
) {
    private static final String POSTER_IMG = "https://image.tmdb.org/t/p/w500";
    private static final String BACKDROP_IMG = "https://image.tmdb.org/t/p/w1280";

    private static String imageUrl(String base, String path) {
        return (path == null || path.isBlank()) ? null : base + path;
    }

    public static MovieDto from(TmdbMovie m) {
        return new MovieDto(
            m.id(), m.title(), m.overview(),
            imageUrl(POSTER_IMG, m.posterPath()),
            imageUrl(BACKDROP_IMG, m.backdropPath()),
            m.releaseDate()
        );
    }

    public static MovieDto fromEntity(Movie m) {
        return new MovieDto(
            m.getTmdbId(), m.getTitle(), m.getOverview(),
            imageUrl(POSTER_IMG, m.getPosterPath()),
            imageUrl(BACKDROP_IMG, m.getBackdropPath()),
            m.getReleaseDate() == null ? null : m.getReleaseDate().toString()
        );
    }
}