package com.movieranker.api.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;
import java.util.UUID;

import com.movieranker.api.entity.MovieList;
public interface MovieListRepository extends JpaRepository<MovieList, Long> {
    Optional<MovieList> findByUserId(UUID userId);
}

