package com.movieranker.api.service;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestClient;
import org.springframework.web.server.ResponseStatusException;

import com.movieranker.api.dto.TMDB.TmdbMovie;
import com.movieranker.api.dto.TMDB.TmdbSearchResponse;

@Service
public class TmdbService {
    private final RestClient tmdbClient;

    public TmdbService(RestClient tmdbClient) {
        this.tmdbClient = tmdbClient;
    }

    public List<TmdbMovie> search(String query, int page) {
        if (query == null || query.isBlank() || page < 1) {
            return List.of();
        }

        TmdbSearchResponse res = tmdbClient.get()
            .uri("/search/movie?query={q}&page={p}&include_adult=false", query, page)
            .retrieve()
            .body(TmdbSearchResponse.class);
        return res == null || res.results() == null ? List.of() : res.results();
    }

    public TmdbMovie getMovie(int tmdbId) {
        if (tmdbId < 1) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Movie not found on TMDB");
        }

        try {
            TmdbMovie movie = tmdbClient.get().uri("/movie/{id}", tmdbId)
                .retrieve().body(TmdbMovie.class);
            if (movie == null) {
                throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Movie not found on TMDB");
            }
            return movie;
        } catch (HttpClientErrorException.NotFound e) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Movie not found on TMDB");
        }
    }
}