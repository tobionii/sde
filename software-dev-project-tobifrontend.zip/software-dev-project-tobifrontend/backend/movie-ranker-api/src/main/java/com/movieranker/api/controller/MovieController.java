package com.movieranker.api.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.movieranker.api.dto.TMDB.MovieDto;
import com.movieranker.api.service.TmdbService;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/movies")
@RequiredArgsConstructor
public class MovieController {
    private final TmdbService tmdb;

    @GetMapping("/search")
    public List<MovieDto> search(@RequestParam String query,
                                 @RequestParam(defaultValue = "1") int page) {
        if (query.isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "query is required");
        return tmdb.search(query.trim(), page).stream().map(MovieDto::from).toList();
    }

    @GetMapping("/{tmdbId}")
    public MovieDto get(@PathVariable int tmdbId) {
        return MovieDto.from(tmdb.getMovie(tmdbId));
    }
}