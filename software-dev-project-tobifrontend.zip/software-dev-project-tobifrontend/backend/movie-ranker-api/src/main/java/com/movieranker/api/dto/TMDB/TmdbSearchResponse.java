package com.movieranker.api.dto.TMDB;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public record TmdbSearchResponse(
    int page,
    List<TmdbMovie> results
) {}