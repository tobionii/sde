package com.movieranker.api.dto.TMDB;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.util.List;

public record ReplaceTopMoviesRequest(
    @NotNull @Size(min = 1, max = 5) List<@Valid TopMovieItem> movies
) {}